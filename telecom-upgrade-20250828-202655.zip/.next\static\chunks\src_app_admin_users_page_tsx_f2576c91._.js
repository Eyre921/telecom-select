(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_f7b787d4._.js",
  "static/chunks/node_modules_3ce0805e._.js"
],
    source: "dynamic"
});
